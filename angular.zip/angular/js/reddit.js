	
	(function (angular) {	
			var app = angular.module('list', []);
			app.controller('listCtrl', function($scope, $http) {		
				let limitElements = 0, url = 'http://www.reddit.com/r/javascript.json?limit=';		  
				function htmlUnescape(value){
					return String(value)
						.replace(/&quot;/g, '"')
						.replace(/&#39;/g, "'")
						.replace(/&lt;/g, '<')
						.replace(/&gt;/g, '>')
						.replace(/&amp;/g, '&');
				}
				$scope.getJson = function(url,limitElements){
						$http.get(url+limitElements)
						  .success(function(data, status, headers, config) {
							$scope.dataList = data.data.children;	
							console.log(status + ' ' + headers +  ' ' + config);
						  })
						  .error(function(data, status, headers, config) {
								alert(status);
						});			
					}	
				 $scope.moreItems = function(){
					limitElements = limitElements + 25;
					if(limitElements > 25)
						$(".prev").show();

					$scope.getJson(url,limitElements);
				 }
				 $scope.lessItems = function(){
					limitElements = limitElements - 25;
					if(limitElements == 25)
						$('.prev').hide();
						
					$scope.getJson(url,limitElements);
				 }
				 $scope.moreItems();
			  
				$scope.replies = function( obj, id ){
						let replies, contentReplices = '';
					  function authorComment(author){
						return '<div class="author">' + author + '</div>'
					  }
					  angular.forEach(obj, function (item, i) {		
						comment = '<div class="comment">' + item.data.body_html + '</div>';
						author = authorComment(item.data.author);	
					
						if(item.data.replies.data)
						{
						  angular.forEach(item.data.replies.data.children, function (item, i) {				
							replies = authorComment(item.data.author) + "<div class='replies'>" + item.data.body_html + "</div>" ;
						 });
						}
						
						if(replies == undefined)
						{
							replies = '';
						}
						
						contentReplices += author + comment + replies;
						replies = '';
						author = '';
					  });	  
					  
						$('#'+id).find('.comment')[0].innerHTML = htmlUnescape(contentReplices);			
				}
				$scope.showContent = function(url, event, typeLink) {		
					if(typeLink == 'self.javascript')
					{
					  let title, author, comment = '';
					  
					  $http.get(url + ".json?jsonp=")
					  .then(function(response) {								
						$('#'+event.target.id).find('.title')[0].innerHTML = response.data[0].data.children[0].data.title;						
						$('#'+event.target.id).find('.dataListContentSelftext_html')[0].innerHTML = htmlUnescape(response.data[0].data.children[0].data.selftext_html);
						$scope.replies(response.data[1].data.children, event.target.id);
					  });
					 }
					 else{
						window.open(url, '_blank');
					 }	
			}; 
			});
	})(angular);

it('should demonstrate using when (200 status)', inject(function($httpBackend, $http) {
	  let $scope = {}, url = 'http://www.reddit.com/r/javascript.json?limit=25';
	  $http.get( url )
		.success(function(data, status, headers, config) {
		  $scope.valid = true;
		  $scope.response = data;
		})
		.error(function(data, status, headers, config) {
		  $scope.valid = false;
	  });
	 $httpBackend
		.when('GET', url)
		.respond(200, { foo: 'bar' });
	  $httpBackend.flush();
	  expect($scope.valid).toBe(true);
	  expect($scope.response).toEqual({ foo: 'bar' });
})); 
